<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="format-detection" content="telephone=no">
<title>UMS | Advertising Creative Agency</title>
<meta name="author" content="Themezinho">
<meta name="description" content="Anchor | Freelancer & Creative Agency Portfolio">
<meta name="keywords" content="creative, works" >
<meta property="og:description" content="UMS | Advertising Creative Agency">
<meta property="og:image" content="http://www.themezinho.net/Anchor/preview.png">
<meta property="og:site_name" content="UMS">
<meta property="og:title" content="UMS | Advertising Creative Agency">
<meta property="og:type" content="website">
<meta property="og:url" content="http://www.themezinho.net/Anchor">

<!-- TWITTER META -->
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@Anchor">
<meta name="twitter:creator" content="@Anchor">
<meta name="twitter:title" content="Anchor">
<meta name="twitter:description" content="UMS | Advertising Creative Agency">
<meta name="twitter:image" content="http://www.themezinho.net/Anchor/preview.png">

<!-- FAVICON FILES -->
<link href="images/apple-touch-icon-144-precomposed.png" rel="apple-touch-icon" sizes="144x144">
<link href="images/apple-touch-icon-114-precomposed.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-72-precomposed.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-57-precomposed.png" rel="apple-touch-icon">
<link href="images/favicon.png" rel="shortcut icon">

<!-- CSS FILES -->
<link rel="stylesheet" href="css/animate.min.css">
<link rel="stylesheet" href="css/hamburger-menu.css">
<link rel="stylesheet" href="css/odometer.min.css">
<link rel="stylesheet" href="css/swiper.min.css">
<link rel="stylesheet" href="css/fancybox.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">



  
<script>
    "use strict";
var testim = document.getElementById("testim"),
  testimDots = Array.prototype.slice.call(
    document.getElementById("testim-dots").children
  ),
  testimContent = Array.prototype.slice.call(
    document.getElementById("testim-content").children
  ),
  testimLeftArrow = document.getElementById("left-arrow"),
  testimRightArrow = document.getElementById("right-arrow"),
  testimSpeed = 4500,
  currentSlide = 0,
  currentActive = 0,
  testimTimer,
  touchStartPos,
  touchEndPos,
  touchPosDiff,
  ignoreTouch = 30;
window.onload = function () {
  // Testim Script
  function playSlide(slide) {
    for (var k = 0; k < testimDots.length; k++) {
      testimContent[k].classList.remove("active");
      testimContent[k].classList.remove("inactive");
      testimDots[k].classList.remove("active");
    }

    if (slide < 0) {
      slide = currentSlide = testimContent.length - 1;
    }

    if (slide > testimContent.length - 1) {
      slide = currentSlide = 0;
    }

    if (currentActive != currentSlide) {
      testimContent[currentActive].classList.add("inactive");
    }
    testimContent[slide].classList.add("active");
    testimDots[slide].classList.add("active");

    currentActive = currentSlide;

    clearTimeout(testimTimer);
    testimTimer = setTimeout(function () {
      playSlide((currentSlide += 1));
    }, testimSpeed);
  }

  testimLeftArrow.addEventListener("click", function () {
    playSlide((currentSlide -= 1));
  });

  testimRightArrow.addEventListener("click", function () {
    playSlide((currentSlide += 1));
  });

  for (var l = 0; l < testimDots.length; l++) {
    testimDots[l].addEventListener("click", function () {
      playSlide((currentSlide = testimDots.indexOf(this)));
    });
  }

  playSlide(currentSlide);

  // keyboard shortcuts
  document.addEventListener("keyup", function (e) {
    switch (e.keyCode) {
      case 37:
        testimLeftArrow.click();
        break;

      case 39:
        testimRightArrow.click();
        break;

      case 39:
        testimRightArrow.click();
        break;

      default:
        break;
    }
  });

  testim.addEventListener("touchstart", function (e) {
    touchStartPos = e.changedTouches[0].clientX;
  });

  testim.addEventListener("touchend", function (e) {
    touchEndPos = e.changedTouches[0].clientX;

    touchPosDiff = touchStartPos - touchEndPos;

    console.log(touchPosDiff);
    console.log(touchStartPos);
    console.log(touchEndPos);

    if (touchPosDiff > 0 + ignoreTouch) {
      testimLeftArrow.click();
    } else if (touchPosDiff < 0 - ignoreTouch) {
      testimRightArrow.click();
    } else {
      return;
    }
  });
};

</script>

</head>
<body>
<!--<body oncontextmenu="return false;">
<div class="preloader"> <img src="images/ums-logo-preloader.gif" alt="Image">
 <!-- <ul class="text-rotater">
    <li>Hangin there</li>
    <li>Still loading</li>
    <li>Almost done</li>
  </ul>-->
</div>
<!-- end preloader -->
<div class="transition-overlay"></div>
<!-- end transition-overlay -->
<main>
  <ul class="hamburger-navigation">
    <li><a href="index.php">Home</a>
    </li>
    <li><a style="color:white">About Us</a>
     <ul class="dropdown">
    	<li><a href="advertising.php">Advertising & Marketing</a></li>
    	<li><a href="branding.php">Branding </a></li>
    	<li><a href="web-and-app.php">Web & App</a></li>
    </ul>
      </li>
      <li><a style="color:white">OOH</a>
      <ul class="dropdown">
    	<li><a href="theatre-release.php">Cinema</a></li>
    	<li><a href="led-screens.php">LED Screens</a></li>
    	<li><a href="lift-branding.php">Lift Branding</a></li>
    	<li><a href="metro.php">Metro</a></li>
    	<li><a href="bus-branding.php">Bus Branding</a></li>
    	<li><a href="radio.php">Radio</a></li>
    	<li><a href="mobile-van-branding.php">Mobile Van Branding</a></li>
    	<li><a href="print-services.php">Print Services</a></li>
    </ul>
      </li>
       <li><a href="event-management.php"> Event Management</a> </li>
  
    <li><a href="contact.php">Say Hello</a> </li>
  </ul>
  <!-- end hamburger-navigation -->
  <svg class="shape-overlays" viewBox="0 0 100 100" preserveAspectRatio="none">
    <path class="shape-overlays__path" d=""></path>
    <path class="shape-overlays__path" d=""></path>
    <path class="shape-overlays__path" d=""></path>
  </svg>
  <header class="header" >
    <div class="logo"><a href="index.php"><img src="images/ums-logo.png" alt="ums logo" style="width:300px"></a></div>
    <!-- end logo --> 
     <!--  <span class="phone">t: +380 83 857 5 577</span> --> 
    <div class="hamburger" id="hamburger">
      <div class="hamburger__line hamburger__line--01">
        <div class="hamburger__line-in hamburger__line-in--01"></div>
      </div>
      <div class="hamburger__line hamburger__line--02">
        <div class="hamburger__line-in hamburger__line-in--02"></div>
      </div>
      <div class="hamburger__line hamburger__line--03">
        <div class="hamburger__line-in hamburger__line-in--03"></div>
      </div>
      <div class="hamburger__line hamburger__line--cross01">
        <div class="hamburger__line-in hamburger__line-in--cross01"></div>
      </div>
      <div class="hamburger__line hamburger__line--cross02">
        <div class="hamburger__line-in hamburger__line-in--cross02"></div>
      </div>
    </div>
    <!-- end hamburger 
    <div class="equalizer"> <span></span> <span></span> <span></span> <span></span> </div>
    <!-- end equalizer -->
   
  </header>
  <ul class="social-bar">
    <li><a href="#">FB</a></li>
    <li><a href="#">IN</a></li>
    <li><a href="#">TY</a></li>
    <li><a href="#">X</a></li>
  </ul>
 <section class="int-hero">
    
    <div class="inner">
      <h2>KSRTC / Private Bus Branding</h2>
    </div>
    <!-- end inner --> 
  </section>
  
  
<section class="content" style="padding-bottom:30px">
    <div class="about-studio">
      <figure class="hero-image wow fadeInUp" style="margin-bottom: 30px;"> <img class="metroimg" src="images/bus-branding/bus-branding.png" alt="Image"></figure>
      <div class="container">
        <div class="row">
          
          <!-- end col-4 -->
          <div class="col-md-8 wow fadeInRight">
            <p class="lead" style="margin-bottom:0px;line-height: 30px; max-width: 100%;">Advertisements will be visible on three sides of the bus body.</p>
            <!-- <p class="lead" style="margin-bottom:0px;line-height: 30px; max-width: 100%;"><span class="bold">For KSRTC Bus</span>: ₹11,500 per month</p>
            <p class="lead" style="margin-bottom:0px;line-height: 30px; max-width: 100%;"><span class="bold">For Private Bus</span>: ₹70,000 for 6 months</p>-->
            
           
        
          </div>
          <!--end col-6 --> 
        </div>
        <!-- end row --> 
      </div>
      <!-- end container --> 
    </div>
    <!-- end about-studio -->
   
  </section>
  
  
   <section class="content">
   	<div class="works three-cols">
            <div class="grid-sizer"></div>
            <!-- end grid-sizer -->
            <div class="grid-item one">
              <figure class="reveal-effect se2-white wow perspective-box"> <img src="images/vehilcle-branding/vehilcle-branding-KSRTC-bus-branding.jpeg" alt="Image">
                <figcaption> <a data-fancybox="gallery" href="images/vehicle-branding/vehilcle-branding-KSRTC-bus-branding.jpeg">
                  <div class="bg-color" data-background="#2095f4"></div>
            <!-- end bg-color -->
            
            <!-- end brand -->
            </a> </figcaption>
                </figure>
            </div>
            
            
            <!-- end grid-item -->
            <div class="grid-item two">
              <figure class="reveal-effect se2-white wow perspective-box"><img src="images/vehilcle-branding/vehilcle-branding-KSRTC-bus-branding-1.jpeg" alt="Image">
                <figcaption> <a data-fancybox="gallery" href="images/vehilcle-branding/vehilcle-branding-KSRTC-bus-branding-1.jpeg">
					  <div class="bg-color" data-background="#ffc509"></div>
            <!-- end bg-color -->
          
           </a> </figcaption>
            </figure>
            </div>
           
          </div>
          <!-- end works -->
    <!-- end works --> 
  </section>
  <!-- end content --> 
</main>
<div class="footer-spacing"></div>



<!-- end footer-spacing -->
<footer class="footer"> 
  <ul class="social-media">
    <li><a href="#">FB</a></li>
    <li><a href="#">TW</a></li>
    <li><a href="#">YT</a></li>
    <li><a href="#">BE</a></li>
  </ul>
  <h4>Creativity is Everywhere</h4>
  <h2 style="font-family: 'nasalization';font-size: 35px;">Have an idea or project? Let's talk</h2>
  <a href="contact.php" class="btn-contact"><span data-hover="LET'S BE IN TOUCH">LET'S BE IN TOUCH</span></a>
  <div class="footer-bar"> <span class="pull-left">© 2024 UMS - All rights reserved.</span> </div>
  <!-- end footer-bar --> 
</footer>
<!-- end footer 
<audio id="link" src="audio/link.mp3" preload="auto"></audio>-->

<!-- JS FILES --> 
<script src="js/jquery.min.js"></script> 
<script>
	// PRELOADER
		(function($) {
			$(window).load(function(){
				$("body").addClass("page-loaded");	
			});
		})(jQuery)
</script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/swiper.min.js"></script> 
<script src="js/fancybox.min.js"></script> 
<script src="js/jquery.stellar.js"></script> 
<script src="js/odometer.min.js"></script> 
<script src="js/hamburger.min.js"></script> 
<script src="js/easings.js"></script> 
<script src="js/isotope.min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="js/perspective.min.js"></script> 
<script src="js/scripts.js"></script>




</body>
</html>